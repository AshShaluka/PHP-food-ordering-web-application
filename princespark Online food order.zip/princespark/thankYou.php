<?php
  require_once 'core/init.php';

  //Get post data
  $full_name = sanitize($_POST['full_name']);
  $email = sanitize($_POST['email']);
  $street = sanitize($_POST['street']);
  $street2 = sanitize($_POST['street2']);
  $city = sanitize($_POST['city']);
  $d_cost = sanitize($_POST['d_cost']);
  $sub_total = sanitize($_POST['sub_total']);
  $grand_total = sanitize($_POST['grand_total']);
  $cart_id = sanitize($_POST['cart_id']);
  $description = sanitize($_POST['description']);

  $db->query("UPDATE cart SET paid = 1 WHERE id = '{$cart_id}' ");
  $db->query("INSERT INTO transactions
    (charge_id,cart_id,full_name,email,street,street2,city,sub_total,d_cost,grand_total,description,txn_type) VALUES
    ('1','$cart_id','$full_name','$email','$street','$street2','$city','$sub_total','$d_cost','$grand_total','$description','Cash')");

$domain = ($_SERVER['HTTP_HOST'] != 'localhost:81')? '.'.$_SERVER['HTTP_HOST']:false;
setcookie(CART_COOKIE,'',1,"/",$domain,false);

include 'includes/menu_head.php';
include 'includes/cart_head.php';
include 'includes/cart_breadcrumb.php';
 ?>
  <h1 class="text-center text-success">Thank You!</h1>
  <p>Your bill is <?=money($grand_total);?>. You have been emailed a reciept. Please check your spam folder if it is not your inbox.</p>
  <p>Your receipt number is: <strong><?=$cart_id;?></strong></p>
  <p>Your order will be deliver to the address below.</p>
  <address>
    <?=$full_name;?><br>
    <?=$street;?><br>
    <?=(($street2 != '')?$street2.'<br>':'');?><br>
    <?=$city;?><br>
  </address>
<?php
  include 'includes/menu_footer.php';
 ?>
