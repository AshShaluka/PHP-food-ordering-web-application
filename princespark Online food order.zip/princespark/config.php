<?php
  define('BASEURL', $_SERVER['DOCUMENT_ROOT'].'/princespark/');
  define('CART_COOKIE','SBwi72uklwiqzz2');
  define('CART_COOKIE_EXPIRE',time() + (86400 *30));
  define('DCOST', 0.050 );
