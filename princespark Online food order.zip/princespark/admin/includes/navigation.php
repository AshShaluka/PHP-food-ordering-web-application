        <div class="row h-100">
            <div class="col-12 h-100">
                <nav class=" navbar navbar-expand-lg bg-dark">
                    <a class="navbar-brand" href="index.php">Princess Park Restaurant</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#caviarNav" aria-controls="caviarNav" aria-expanded="false" aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
                    <div class="collapse navbar-collapse" id="caviarNav">
                        <ul class="navbar-nav ml-auto" id="caviarMenu">
                          <li class="nav-item">
                              <a class="nav-link" href="brand.php">Brand<span class="sr-only">(current)</span></a>
                          </li>
                            <li class="nav-item">
                                <a class="nav-link" href="category.php">Category<span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="foods.php">Foods</a>
                            </li>
                    </div>
                </nav>
            </div>
        </div>
