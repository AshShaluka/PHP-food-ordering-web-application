</div>

<!-- ***** Special Menu Area Start ***** -->
<section class="caviar-dish-menu clearfix" id="menu">

</section>
<!-- ***** Special Menu Area End ***** -->
    <!-- ***** Footer Area Start ***** -->
    <footer class="caviar-footer-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="footer-text">
                        <a href="#" class="navbar-brand">Princess Park Restaurant</a>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ***** Footer Area Start ***** -->

    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/others/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
    <script src="js/bootstrap/bootstrap.bundle.js"></script>
    <script src="js/bootstrap/bootstrap.bundle.js.map"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <script type="text/javascript">
      function get_child_options(){
        var parentID = jQuery('#parent').val();
        jQuery.ajax({
          url: '/backup/admin/parsers/child_categories.php',
          type: 'POST',
          data: {parentID : parentID},
          success: function(data){
            jQuery('#child').html(data);
          },
          error: function(){alert("Something went wrong with the child options.")},
        });
      }
      jQuery('select[name="parent"]').change(get_child_options);
    </script>
  </body>
</html>
