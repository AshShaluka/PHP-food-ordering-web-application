<?php
  require_once $_SERVER['DOCUMENT_ROOT'].'/princespark/core/init.php';
  include 'includes/head.php';
  include 'includes/navigation.php';
  if(isset($_GET['add'])){
  $brandQuery = $db->query("SELECT * FROM brand ORDER BY brand");
  $parentQuery = $db->query("SELECT * FROM categories WHERE parent = 0");
  if($_POST){
    $title = sanitize($_POST['title']);
    $brand = sanitize($_POST['brand']);
    $categories = sanitize($_POST['child']);
    $price = sanitize($_POST['price']);
    $description = sanitize($_POST['description']);
    $dbPath = '';
    $errors = array();
    $required = array('title', 'brand', 'price', 'parent', 'child');
    foreach ($required as $field) {
      if($_POST[$field] == ''){
        $errors[] = 'All Feilds With Astrisk are Required';
        break;
      }
    }
    if(!empty($_FILES)){
      var_dump($_FILES);
      $photo = $_FILES['photo'];
      $name = $photo['name'];
      $nameArray = explode('.',$name);
      $fileName = $nameArray[0];
      $fileExt = $nameArray[1];
      $mime = explode('/',$photo['type']);
      $mimeType = $mime[0];
      $mimeExt = $mime[1];
      $tmpLoc = $photo['tmp_name'];
      $fileSize = $photo['size'];
      $allowed = array('png','jpg','jpeg','gif');
      $uploadName = md5(microtime()).'.'.$fileExt;
      $uploadPath = BASEURL.'img/foods/'.$uploadName;
      $dbPath = '/backup/img/foods/'.$uploadName;
      if($mimeType != 'image'){
        $errors[] = 'The file must be an image.';
      }
      if(!in_array($fileExt, $allowed)){
        $errors[] = 'The file extension must be a png, jpg, jpeg, or gif.';
      }
      if($fileSize > 25000000){
        $errors = 'The file size must be under 25MB.';
      }
      if($fileExt != $mimeExt && ($mimeExt == 'jpeg' && $fileExt != 'jpg')){
        $errors = 'File extension does not match the file.';
      }
    }
    if(!empty($errors)){
      echo display_errors($errors);
    }else{
      //upload file and insert into database
      move_uploaded_file($tmpLoc,$uploadPath);
      $insertSql = "INSERT INTO foods (`title`,`price`,`brand`,`categories`,`image`)
       VALUES ('$title', '$price', '$brand', '$categories', '$dbPath')";
       $db->query($insertSql);
       header('Location: foods.php');
    }


  }

  ?>
  <h2 class="text-center">Add A New Food</h2><hr>
  <form action="foods.php?add=1" method="post" enctype="multipart/form-data">
    <div class="form-group col-md-3">
      <label for="title">Title* :</label>
      <input type="text" name="title" class="form-control" id="title" value="<?=((isset($_POST['title']))?sanitize($_POST['title']):'');?>">
    </div>
    <div class="form-group col-md-3">
      <label for="brand">Couisine* :</label>
      <select class="form-control" style=" height:35px" id="name" name="brand">
        <option value=""<?=((isset($_POST['brand']) && $_POST['brand'] == '')?' selected':'');?>></option>
        <?php while($brand = mysqli_fetch_assoc($brandQuery)): ?>
          <option value="<?=$brand['id'];?>"<?=((isset($_POST['brand']) && $_POST['brand'] == $brand['id'])?' selected':'');?>><?=$brand['brand'];?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="form-group col-md-3">
      <label for="parent">Parent Category* :</label>
      <select class="form-control" style="height:35px" name="parent" id="parent">
        <option value=""<?=((isset($_POST['parent']) && $_POST['parent'] == '')?' selected':'');?>></option>
        <?php while($parent = mysqli_fetch_assoc($parentQuery)): ?>
          <option value="<?=$parent['id']?>"<?=((isset($_POST['parent']) && $_POST['parent'] == $parent['id'])?' select':'');?>><?=$parent['category'];?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="form-group col-md-3">
      <label for="child">Child Category* :</label>
      <select class="form-control" style="height:35px" name="child" id="child">
      </select>
    </div>
    <div class="form-group col-md-3">
      <label for="price">Price* :</label>
      <input type="text" name="price" id="price" class="form-control" value="<?=((isset($_POST['price']))?sanitize($_POST['price']):'');?>">
    </div>
    <div class="form-group col-md-3">
      <label for="photo">Food Photo :</label>
      <input type="file" name="photo" id="photo" class="form-control">
    </div>
    <div class="form-group col-md-6">
      <label for="description">Description :</label>
      <textarea name="description" id="description" class="form-control" rows="6"><?=((isset($_POST['description']))?sanitize($_POST['description']):'');?></textarea>
    </div>
    <div class="form-group pull-right">
      <input type="submit" value="Add Food" class="form-control btn btn-success">
      <div class="clearfix"></div>
    </div>

  </form>


  <?php
  }else{
  $sql = "SELECT * FROM foods WHERE deleted = 0";
  $presults = $db->query($sql);
  if(isset($_GET['featured'])){
    $id = (int)$_GET['id'];
    $featured = (int)$_GET['featured'];
    $featuredSql = "UPDATE foods SET featured = '$featured' WHERE id = '$id'";
    $db->query($featuredSql);
    header('Location: foods.php');
  }

?>
<h2 class="text-center">Foods</h2>
<a href="foods.php?add=1" class="btn btn-success pull-right" id="add-product-btn">Add Food</a><div class="clearfix"></div>
<hr>
<table class="table table-bordered table-condensed table-striped">
  <thead><th></th><th>Foods</th><th>Price</th><th>Categories</th><th>Featuerd</th></thead>
  <tbody>
    <?php while($product = mysqli_fetch_assoc($presults)):
      $childID = $product['categories'];
      $catSql = "SELECT * FROM categories WHERE id = '$childID'";
      $result = $db->query($catSql);
      $child = mysqli_fetch_assoc($result);
      $parentID = $child['parent'];
      $pSql = "SELECT * FROM categories WHERE id = '$parentID'";
      $presult = $db->query($pSql);
      $parent = mysqli_fetch_assoc($presult);
      $category = $parent['category'].'~'.$child['category'];
      ?>
      <tr>
        <td>
          <a href="foods.php?edit=<?=$product['id'];?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-pencil"></span></a>
          <a href="foods.php?delete=<?=$product['id'];?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-remove"></span></a>
        </td>
        <td><?=$product['title'];?></td>
        <td><?=money($product['price']);?> </td>
        <td><?=$category;?></td>
        <td><a href="foods.php?featured=<?=(($product['featured'] == 0)?'1':'0')?>&id=<?=$product['id'];?>" class=" btn btn-xs btn-default ">
          <span class="glyphicon glyphicon-<?=(($product['featured']==1)?'minus':'plus')?>"></span>
        </a>
        &nbsp <?=(($product['featured'] == 1)?'Featured Food':'')?>
      </td>
        <td>0</td>
      </tr>
    <?php endwhile; ?>
  </tbody>
</table>


<?php } include 'includes/footer.php'; ?>
