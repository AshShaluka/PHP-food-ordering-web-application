<?php
require_once 'core/init.php';
include 'includes/menu_head.php';
include 'includes/menu_preload.php';
include 'includes/cart_head.php';
include 'includes/cart_breadcrumb.php';
include 'includes/cart_modal.php';



if($cart_id != ''){
  $cartQ = $db->query("SELECT * FROM cart WHERE id = '{$cart_id}'");
  $result = mysqli_fetch_assoc($cartQ);
  $items = json_decode($result['items'],true);
  $i = 1;
  $sub_total = 0;
  $item_count = 0;
}
?>
<div class="col-md-12">
    <h2 class="text-center">My Shopping Cart</h2><hr>
    <?php if($cart_id == ''): ?>
      <div>
        <p class="text-center text-danger">
          Your shopping cart is empty !
        </p>
      </div>
    <?php else: ?>
        <table class="table table-bordered table-condensed table-striped">
          <thead><th>#</th><th>Item</th><th>Price</th><th>Quantity</th><th>Sub Total</th></thead>
          <tbody>
              <?php
                foreach($items as $item){
                  $product_id = $item['id'];
                  $productQ = $db->query("SELECT * FROM foods WHERE id = '{$product_id}'");
                  $product = mysqli_fetch_assoc($productQ);
                  ?>
                  <tr>
                    <td><?=$i;?></td>
                    <td><?=$product['title'];?></td>
                    <td><?=money($product['price']);?></td>
                    <td>
                        <button class="btn btn-xs btn-default" onclick="update_cart('removeone','<?=$product['id'];?>');">-</button>
                      <?=$item['quantity'];?>
                        <button class="btn btn-xs btn-default" onclick="update_cart('addone','<?=$product['id'];?>');">+</button>
                    </td>
                    <td><?=money($item['quantity'] * $product['price']);?></td>
                  </tr>

                  <?php
                  $i++;
                  $item_count += $item['quantity'];
                  $sub_total += ($product['price'] * $item['quantity']);
                }
                $d_cost = DCOST * $sub_total;
                $d_cost = number_format($d_cost,2);
                $grand_total = $d_cost + $sub_total;

               ?>
          </tbody>
        </table>
      </br></br>
        <table class="table table-bordered table-condensed text-right">
          <legend>Totals</legend>
          <thead class="totals-table-header"><th>Total Items</th><th>Sub Total</th><th>Delivery Cost</th><th>Grand Total</th></thead>
          <tbody>
              <tr>
                <td><?=$item_count;?></td>
                <td><?=money($sub_total);?></td>
                <td><?=money($d_cost);?></td>
                <td><?=money($grand_total);?></td>
              </tr>
          </tbody>
        </table>

        <!-- Checkout Button -->
<button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#checkoutModal">
  <span class="glyphicon glyphicon-shopping-cart"></span> Check Out
</button>



    <?php endif; ?>
</div>
<script>

  function back_address(){

    jQuery('#payment-errors').html("");
    jQuery('#step1').css("display","block");
    jQuery('#step2').css("display","none");
    jQuery('#next_button').css("display","inline-block");
    jQuery('#back_button').css("display","none");
    jQuery('#checkout_button').css("display","none");
    jQuery('#checkouModalLabel').html("Shipping Address");

  }


  function check_address(){
     var data = {
        'full_name' : jQuery('#full_name').val(),
        'email' : jQuery('#email').val(),
        'street' : jQuery('#street').val(),
        'street2' : jQuery('#street2').val(),
        'city' : jQuery('#city').val(),

   };
   jQuery.ajax({
     url : '/princespark/admin/parsers/check_address.php',
     method : 'POST',
     data : data,
     success : function(data){
       if(data != 'passed'){
         jQuery('#payment-errors').html(data);

       }
       if(data == 'passed'){
         jQuery('#payment-errors').html("");
         jQuery('#step1').css("display","none");
         jQuery('#step2').css("display","block");
         jQuery('#next_button').css("display","none");
         jQuery('#back_button').css("display","inline-block");
         jQuery('#checkout_button').css("display","inline-block");
         jQuery('#checkouModalLabel').html("Payment method");
       }
     },
     error : function(){alert("somthing went wrong");},
   });
  }

</script>

<?php include 'includes/menu_footer.php'; ?>
