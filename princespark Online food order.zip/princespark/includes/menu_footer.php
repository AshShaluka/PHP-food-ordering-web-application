</div>

<!-- ***** Special Menu Area Start ***** -->
<section class="caviar-dish-menu clearfix">

</section>
    <footer class="caviar-footer-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="footer-text">
                        <a href="#" class="navbar-brand">Princess Park Restaurant</a>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ***** Footer Area Start ***** -->

    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/others/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
    <script src="js/bootstrap/bootstrap.bundle.js"></script>
    <script src="js/bootstrap/bootstrap.bundle.js.map"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <script>

      function detailsmodal(id){
        var data = {"id" : id};
        jQuery.ajax({
          url : '/princespark/includes/menu_modal_details.php',
          method : "post",
          data : data,
          success : function(data){
            jQuery('body').append(data);
            jQuery('#details-modal').modal('toggle');
          },
          error : function(){
            alert("Somthing went wrong");
          }
        });
      }

      function update_cart(mode,edit_id){
        var data = {'mode' : mode, "edit_id" : edit_id};
        jQuery.ajax({
          url : '/princespark/admin/parsers/update_cart.php',
          method : "post",
          data : data,
          success : function(){
            location.reload();
          },
          error : function(){alert("Somthing went wrong");},
        });
      }

      function add_to_cart(){
        jQuery('#modal_errors').html("");
        var quantity = jQuery('#quantity').val();
        var error = '';
        var data = jQuery('#add_product_form').serialize();

        if(quantity == '' || quantity == 0){
          error += '<p class="text-danger text-center">You must choose quantity</p>';
          jQuery('#modal_errors').html(error);
          return;
        }else{
          jQuery.ajax({
            url: "/princespark/admin/parsers/add_cart.php",
            method : 'post',
            data : data,
            success : function(){
              location.reload();
            },
            error : function(){alert("Somthing went wrong");}
          });
        }
      }

    </script>
  </body>
</html>
