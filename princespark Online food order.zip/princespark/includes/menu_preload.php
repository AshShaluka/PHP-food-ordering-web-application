<!-- Preloader -->
<div id="preloader">
    <div class="caviar-load"></div>
    <div class="preload-icons">
        <img class="preload-1" src="img/core-img/preload-1.png" alt="">
        <img class="preload-2" src="img/core-img/preload-2.png" alt="">
        <img class="preload-3" src="img/core-img/preload-3.png" alt="">
    </div>
</div>
