<div class="col-md-2">
               <?php
                 include 'widgets/cart.php';
                ?>
</div>
