<!-- Modal -->

<div class="modal fade details-1" id="checkoutModal" tabindex="-1" role="dialog" aria-labelledby="checkoutModalLabel" area-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
      </div>
      <div class="modal-header">
      </div>
      <div class="modal-header">
        <h4 class="modal-title" id="checkouModalLabel">Shipping Address</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

      </div>
      <div class="modal-body">
        <form action="thankYou.php" method="post" id="payment-form">
          <span class="bg-danger" id="payment-errors"></span>
          <input type="hidden" name="d_cost" value="<?=$d_cost;?>">
          <input type="hidden" name="sub_total" value="<?=$sub_total;?>">
          <input type="hidden" name="grand_total" value="<?=$grand_total;?>">
          <input type="hidden" name="cart_id" value="<?=$cart_id;?>">
          <input type="hidden" name="description" value="<?=$item_count.' item'.(($item_count>1)?'s':'').' from Princess Park.';?>">
          <div id="step1" style="display:block;">
            <div class="form-group col-md-6">
              <label for="full_name">Full Name:</label>
              <input class="form-control" type="text" name="full_name"  id ="full_name">
            </div>
            <div class="form-group col-md-6">
              <label for="email">Email:</label>
              <input class="form-control" type="email" name="email"  id ="email">
            </div>
            <div class="form-group col-md-6">
              <label for="street">Street Address:</label>
              <input class="form-control" type="text" name="street"  id ="street">
            </div>
            <div class="form-group col-md-6">
              <label for="street2">Street Address 2:</label>
              <input class="form-control" type="text" name="street2"  id ="street2">
            </div>
            <div class="form-group col-md-6">
              <label for="city">City:</label>
              <input class="form-control" type="text" name="city"  id ="city">
            </div>
          </div>
          <div id="step2" style="display:none;">
              <div class="form-group col-md-3">
                <input type="radio">
                <label for="name">Cash </label>

              </div>
              <div class="form-group col-md-3">
                <input type="radio" disabled="disabled">
                <label for="name">Credit Card </label>

              </div>
              <div class="form-group col-md-3">
                <input type="radio" disabled="disabled">
                <label for="name">Paypal </label>


              </div>
          </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

        <button type="button" class="btn btn-primary" onclick="check_address();" id="next_button">Next</button>
        <button type="button" class="btn btn-primary" onclick="back_address();" id="back_button" style="display:none;">Back</button>
        <button type="submit" class="btn btn-primary" id="checkout_button" style="display:none;">Check Out</button>
        </form>
      </div>
    </div>
  </div>
</div>
