<?php
  $cat_id = ((isset($_REQUEST['cat']))?sanitize($_REQUEST['cat']):'');
  $b = ((isset($_REQUEST['brand']))?sanitize($_REQUEST['brand']): '');
  $brandQ = $db->query("SELECT * FROM brand ORDER BY brand");
 ?>

<h3 class="text-center">Search By:</h3>
<h4 class="text-center">Category</h4>
<form action="search.php" method="post">
  <input type="hidden" name="cat" value="<?=$cat_id;?>">
  <input type="radio" name="brand" value=""<<?=(($b == '')?' checked':'');?>>All<br>
  <?php while($brand = mysqli_fetch_assoc($brandQ)): ?>
    <input type="radio" name="brand" value="<?=$brand['id'];?>"<?=(($b == $brand['id'])?' checked':'');?>><?=$brand['brand'];?><br>
  <?php endwhile; ?>
  <br>
  <input type="submit" class="btn btn-xs btn-primary" value="search">
</form>
