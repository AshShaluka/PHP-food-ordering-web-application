<?php
  include('init.php');

    if(isset($_POST['submit']))
    {
          $tabNo=$_POST['TableNo'];
          $category=$_POST['category'];
          $maxpep=$_POST['MaxNo'];
          $dicript=$_POST['Dis'];
          $status=$_POST['status'];

              if($_POST['txtid']=="0")
              {
                  //add new table
                  $sql="INSERT INTO t_details(tbNo,cat,maxPep,disc,status) VALUES('$tabNo','$category','$maxpep','$dicript','$status')";
                  $query=mysqli_query($db,$sql);
                  if($query)
                  {
                    //rederected to index when success
                    header("refresh:0; url=Manage_Tables.php");
                  }
              }else{
                echo "update";
              }
            }

 ?>

<!doctype html>
<html>
<head>
  <title>Princess Park Admin</title>
  <link rel="shortcut icon" href="images/logo.png">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>

<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>

  <ul>
  <li><p>Princes Park Restaurant</p></li>
  <li><a></a></li>
  <li><a></a></li>
  <li><a href="index.php">Home</a></li>
  <li><a href="AddTable.php">Add New Table</a></li>
  <li><a href="Manage_Tables.php">Manage Table</a></li>
  <li><a href="Tables.php">Manage Bookings</a></li>
  <li><a href="#">Confim Bookings</a></li>
  <li><a href="#">Reports</a></li>
    <li><a href="#">Logout</a></li>
</ul>

      <div class = "container"><br>
        <h3 class="text-center">Add Table Details</h3><br>
        <div class="col-lg-8 m-auto d-block">
          <form method="post" onsubmit="Validation()" class="bg-light">
            <div class="form-group">
              <lable>Table Number</label>
              <input type="text" name="TableNo" class="form-control" autocomplete="off" id="TN"><input type="hidden" name="txtid" value="0"/>
              <span id="num" class="text-danger font-weight-bold"></span>
        </div>

        <div class="form-group">
          <lable>Category</label>
         <select id="CAT" class="form-control" autocomplete="off"  name="category">
            <option>Lovers</option>
            <option>Family</option>
            <option>Friends</option>
          </select>
          <span id="cat" class="text-danger font-weight-bold"></span>
    </div>

        <div class="form-group">
          <lable>Maximum Number Of People</label>
          <input type="text" name="MaxNo" class="form-control"autocomplete="off" id="MP">
          <span id="max" class="text-danger font-weight-bold"></span>
    </div>

    <div class="form-group">
      <lable>Description</label>
      <textarea class="form-control" rows="3"  name="Dis" autocomplete="off" id="DS"></textarea>
      <span id="dis" class="text-danger font-weight-bold"></span>
    </div>

    <div class="form-group">
      <lable>Status</label>
    <!--  <input type="text" name="category" class="form-control" autocomplete="off" id="CAT"> -->
     <select id="SAT" class="form-control" autocomplete="off"  name="status">
        <option value="1">Booked</option>
        <option value="0">Not Booked</option>
      </select>
      <span id="SAT" class="text-danger font-weight-bold"></span>
</div>

    <input type="submit" name="submit" value="Submit" class="btn btn-info">
    <input type="reset" name="reset" value="Reset" class="btn btn-info">

      </form>
      </div>

      <script type="text/javascript">

        function Validation(){

          var tabno = document.getElementById('TN').value;
          var cat = document.getElementById('CAT').value;
          var max = document.getElementById('MP').value;
          var discript = document.getElementById('DS').value;
          var stat = document.getElementById('SAT').value;


          if(tabno == ""){
            document.getElementById('num').innerHTML = "Please fill this feild with 4 characters";
            return false;
          }


          if(cat == ""){
            document.getElementById('cat').innerHTML = "Please fill this feild";
            return false;
          }

          if(max == ""){
            document.getElementById('max').innerHTML = "Please fill this feild";
            return false;
          }

          if(discript == ""){
            document.getElementById('dis').innerHTML = "Please fill this feild";
            return false;
          }

          if(stat == ""){
            document.getElementById('SAT').innerHTML = "Please fill this feild";
            return false;
          }

        }
    </script>

</body>
</html>
